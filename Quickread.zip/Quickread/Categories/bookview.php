<?php
    // Establish a connection to the database
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "quickread";

    $connection = mysqli_connect($server, $username, $password, $database);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Query to select book information from the database
    $sql = "SELECT * FROM bookinfo";
    $result = mysqli_query($connection, $sql);

    // Check if there are any results
    if (mysqli_num_rows($result) > 0) {
        // Loop through each row in the result set
        while ($row = mysqli_fetch_assoc($result)) {
            // Output the book information within your HTML template
            echo "<div class='book-details'>";
            echo "<img src='images/{$row['title']}.jpg' alt='{$row['title']}' height='350px' width='235px'>";
            echo "<h2>{$row['title']}</h2>";
            echo "<p>Author: {$row['authorName']}</p>";
            echo "<p>Genre: {$row['genre']}</p>";
            echo "<p>Price: ₹ {$row['price']}</p>";
            echo "<p>Quantity: {$row['quantity']}</p>";
            echo "<button class='add-to-cart'>Add to Cart</button>";
            echo "</div>";
        }
    } else {
        echo "No books found in the database.";
    }

    // Close the database connection
    mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Fiction</title>
    <link href="../../HOME.css" rel="stylesheet">
</head>
<body>
    <br>
    <div id="navbar">
        
        <a href="../../index.php" class="home"><img id="logo" src="../../images\quickread_logo.png" alt="Logo"></a>
        <a href="../../profile.php">My Profile</a>

        <a href="../../login.html" class="with_image">Sign in</a>
        <img id="sign_image" src="../../images\signin_image.png" width="19px">

        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="#" class="with_image">My Cart</a>
        <img id="cart_image" src="../../images\cart_image.png" width="19px">

        <a href="../../contantUs.html" class="category" class="home">Contact Us</a>
        <br><br><br>
    </div>
    <div id="category">
        <a href="../Fiction/fiction.html" >Fiction</a>
        <a href="../Romantic/romantic.html"  >Romantic</a>
        <a href="../Mystery/mystery.html" >Mystery</a>
        <a href="../SciFiction/scifiction.html">Science Fiction</a>
        <a href="../Children/children.html" >Children's literature</a>
        <a href="../Comedy/comedy.html" >Comedy</a>
        <a href="../Crime/crime.html" >Crime</a>

    </div>
    <h2 class="category_heading">Fiction</h2>
    <div class="book-box">
    <div id="" class="book">

        <a href="that_night.php">
            <img src="../../images/fictionBooks/That Night.png" alt="that night" height="200px" width="135px" >
            <p class="small_para">that night</p>
            <pre class="small_pre">Horror, Fiction</pre>

            <p class="small_para">₹ 200</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="ThePalace_ofIllusions.php">
            <img src="../../images/fictionBooks/The Palace Of Illusions.png" alt="The Palace of Illusions" height="200px" width="135px" >
            <p class="small_para">The Palace of Illusions</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 250</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="TheLaw_ofAttraction.php">
            <img src="../../images/fictionBooks/The Law Of Attraction.png" alt="The Law of Attraction" height="200px" width="135px" >
            <p class="small_para">The Law of Attraction</p>
            <pre class="small_pre">Love, Fiction</pre>

            <p class="small_para">₹ 310</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="Trust_NOone.html">
            <img src="../../images/fictionBooks/Trust No One.png" alt="Trust No One" height="200px" width="135px" >
            <p class="small_para">Trust No One</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 190</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="Girl_inSeat_2A.html">
            <img src="../../images/fictionBooks/Girl in Seat 2A.png" alt="The Girl in Seat 2A" height="200px" width="135px" >
            <p class="small_para">The Girl in Seat 2A</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 300</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="DaysAtThe_MorisakiBookshop.html">
            <img src="../../images/fictionBooks/Days at the Morisaki Bookshop.png" alt="Days at the Morisaki Bookshop" height="200px" width="135px" >
            <p class="small_para">Days at the Morisaki Bookshop</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 220</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="YouOnly_LiveOnce.html">
            <img src="../../images/fictionBooks/You Only Live Once.png" alt="You Only Live Once"  height="200px" width="135px" >
            <p class="small_para">You Only Live Once</p>
            <pre class="small_pre">Suspense, Fiction</pre>

            <p class="small_para">₹ 170</p>
        </a>
    </div>
</div>





    
</body>
</html>
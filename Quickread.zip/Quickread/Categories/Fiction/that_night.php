<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>That Night</title>
    <link href="../../HOME.css" rel="stylesheet">
</head>
<body>
    <br>
    <div id="navbar">
        
        <a href="../../index.php" class="home"><img id="logo" src="../../images\quickread_logo.png" alt="Logo"></a>
        <a href="../../profile.php">My Profile</a>

        <a href="../../login.html" class="with_image" class="home" >Sign in</a>
        <img id="sign_image" src="../../images\signin_image.png" width="19px">

        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="#" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="../../images\cart_image.png" width="19px">

        <a href="../../contantUs.html" class="category" class="home" >Contact Us</a>
        <br><br><br>
    </div>
    <div id="category">
        <a href="../Fiction/fiction.php" >Fiction</a>
        <a href="../Romantic/romantic.html"  >Romantic</a>
        <a href="../Mystery/mystery.html" >Mystery</a>
        <a href="../SciFiction/scifiction.html">Science Fiction</a>
        <a href="../Children/children.html" >Children's literature</a>
        <a href="../Comedy/comedy.html" >Comedy</a>
        <a href="../Crime/crime.html" >Crime</a>

    </div>

    <div class="book_image">
    <img src="../../images/fictionBooks/That Night.png" alt="That_Night" height="350px" width="235px" >
    <p id="bookName">That Night</p>  
    <pre style="color:grey; "></pre>
    <p id="price">₹ 200</p><del> 320</del>
    <pre>    
    </pre>
        <button class="add_to_cart">Add to Cart</button>

    </div>
</body>
</html>
<?php
session_start();

// Establish a database connection
$server = "localhost";
$username = "root";
$password = "";
$database = "quickread";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (isset($_SESSION["username"])) {
    // Retrieve user information from the session
    $userName = $_SESSION["username"];

    // Query to retrieve user information from the database
    $sqlUser = "SELECT * FROM userinfo WHERE contact_number = '$userName'";
    $resultUser = mysqli_query($connection, $sqlUser);

    if (!$resultUser) {
        die("Query failed: " . mysqli_error($connection));
    }

    if (mysqli_num_rows($resultUser) > 0) {
        // Fetch user data
        $userData = mysqli_fetch_assoc($resultUser);
        $userEmail = $userData["email"];
        $userAddress = $userData["address"];
    }

    // Query to retrieve all order items for the user
    $sqlOrder = "SELECT * FROM orderitem";
    $resultOrder = mysqli_query($connection, $sqlOrder);

    if (!$resultOrder) {
        die("Query failed: " . mysqli_error($connection));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Quickread</title>
    <link href="HOME.css" rel="stylesheet">

    <style>
        table {
    width: 80%;
    border-collapse: collapse;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

    </style>
</head>
<body>
    <br>
    <div id="navbar">
    <a href="./index.php" class="home"><img id="logo" src="images\quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a href="profile.php">My Profile</a>

        
        <?php
            // Check if the user is logged in
            if (isset($_SESSION["username"])) {
                // If logged in, display logout option or any other content for logged-in users
                echo '<a href="./PHP/logout.php">Logout</a>';
            } else {
                // If not logged in, display sign up form or any other content for non-logged-in users
                echo '<a href="./login.html">Sign In</a>';
            }
        ?>


        <!-- <a href="login.html" class="with_image home" >Sign in</a>
        <img id="sign_image" src="images\signin_image.png" width="19px"> -->
        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="cart.php" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="images\cart_image.png" width="19px">

        <a href="contantUs.html" class="category" class="home">Contact Us</a>
        <br><br><br>
    </div>
    
    <div align="center">
        <br><br>
        <?php if(isset($userName)): ?>
            <br><br>
            <h2>Welcome, <?php echo $userName; ?></h2><br>
            <p>Email: <?php echo $userEmail; ?></p><br>
            <p>Contact Number: <?php echo $userName; ?></p><br>
            <p>Address: <?php echo $userAddress; ?></p><br><br>

            <?php if(mysqli_num_rows($resultOrder) > 0): ?>
                <h3>Order Details</h3>
                <table border="1">
                    <tr>
                        <th>Book Name</th>
                        <th>Quantity</th>
                        <th>Cost</th>
                    </tr>
                    <?php while($rowOrder = mysqli_fetch_assoc($resultOrder)): ?>
                        <tr>
                            <td><?php echo $rowOrder["bookname"]; ?></td>
                            <td><?php echo $rowOrder["quantity"]; ?></td>
                            <td><?php echo $rowOrder["cost"]; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>No orders found!</p>
            <?php endif; ?>
        <?php else: ?>
            <h1 style="padding-top: 270px; background-color: #c17ed2;">User not found!</h1>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $cNumber = $_POST['cNumber'];
        $address = isset($_POST['address']) ? $_POST['address'] : "";
        $pass = $_POST['pass'];
        $confirmPass = $_POST['confirmPass'];
    
        // Check if password and confirm password match
        if ($pass !== $confirmPass) {
            echo "Error: Passwords do not match.";
            exit();
        }
        else
        {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "quickread";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
	            die("Connection failed: ". $conn->connect_error);
                exit();
            }
            // Taking all 5 values from the form data(input)
            $name =  $_REQUEST['name'];
            $cNumber = $_REQUEST['cNumber'];
            $email = $_REQUEST['email'];
            $pass =  $_REQUEST['pass'];
            //echo $pass;

            $sqlquery = "INSERT INTO admin (contact_number, name, password, email) VALUES ('$cNumber', '$name', '$pass', '$email')";
            // $sqlquery = "INSERT INTO userinfo (contact_number, name, address, password, email) VALUES ('9876546215', 'mahek', 'abc', 'Mahek@05', 'abc@bvm.com')";
            if ($conn->query($sqlquery) === TRUE) 
            {
	            echo "record inserted successfully";
                header("Location: ../adminLogin.html");
            } 
            else 
            {
	            echo "Error: " . $sqlquery . "<br>" . $conn->error;
                exit();
            }
        }
    }
?>
<?php
    // Start the session
    session_start();

    // Check if the user is logged in
    if (!isset($_SESSION["username"])) {
        // Redirect to login page if not logged in
        header("Location: ./adminLogin.html");
        exit();
    }

    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["changequantity"])) {
        // Database connection
        $server = "localhost";
        $username = "root";
        $password = "";
        $database = "quickread";
        
        $connection = mysqli_connect($server, $username, $password, $database);
        
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get form data
        $id = $_POST["id"];
        $quantityToAdd = $_POST["quantity"];

        // Fetch the current quantity from the database
        $sql = "SELECT quantity FROM bookinfo WHERE id = '$id'";
        $result = mysqli_query($connection, $sql);

        if (!$result) {
            echo "Error fetching current quantity: " . mysqli_error($connection);
            mysqli_close($connection);
            exit();
        }

        // Check if the book ID exists
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $currentQuantity = $row["quantity"];

            // Calculate the new quantity
            $newQuantity = $currentQuantity + $quantityToAdd;

            // Update quantity in the database
            $updateSql = "UPDATE bookinfo SET quantity = '$newQuantity' WHERE id = '$id'";
            
            if (mysqli_query($connection, $updateSql)) {
                echo "Quantity updated successfully";
            } else {
                echo "Error updating quantity: " . mysqli_error($connection);
            }
        } else {
            echo "Book ID not found";
        }

        // Close database connection
        mysqli_close($connection);
    }
?>

<?php
// Start the session
session_start();

// Establish a database connection
$server = "localhost";
$username = "root";
$password = "";
$database = "quickread";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (isset($_SESSION["username"])) {
    // Retrieve user information from the session
    $userName = $_SESSION["username"];

    // Query to retrieve user information from the database
    $sqlUser = "SELECT * FROM admin WHERE contact_number = '$userName'";
    $resultUser = mysqli_query($connection, $sqlUser);

    if (!$resultUser) {
        die("Query failed: " . mysqli_error($connection));
    }

    if (mysqli_num_rows($resultUser) > 0) {
        // Fetch user data
        $userData = mysqli_fetch_assoc($resultUser);
        $userEmail = $userData["email"];
        $userAddress = $userData["address"];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Quickread</title>
    <link href="../../HOME.css" rel="stylesheet">

  
</head>
<body>
    <br>
    <div id="navbar">
        <a href="../../index.php" class="home"><img id="logo" src="../../images/quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a></a>
        <a href="./profile.php">My Profile</a>
            <a></a>
            <a></a>
            <a href="../panel.php">Admin Panel</a>
            <a></a>
            <a></a>
        <?php if(isset($_SESSION["username"])): ?>
            <a href="./PHP/adminLogout.php" class="with_image home">Logout</a>
        <?php else: ?>
            <a href="../adminLogin.html">Sign In</a>
        <?php endif; ?>
    </div>

    
    <div align="center">
        <br><br>
        <?php if(isset($userName)): ?>
            <br><br>
            <h2>Welcome, <?php echo $userName; ?></h2><br>
            <p>Email: <?php echo $userEmail; ?></p><br>
            <p>Contact Number: <?php echo $userName; ?></p><br>
        <?php endif; ?>
    </div>
            
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Quickread</title>
    <link href="../HOME.css" rel="stylesheet">
    <style>
        /* CSS for the form */
        form {
            margin-top: 20px;
            margin-bottom: 20px;
            padding: 20px;
            background-color: #f3e7f3;
            border-radius: 8px;
        }
        table {
            width: 80%;
            margin: 0 auto;
            border-collapse: collapse;
            border-spacing: 0;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .pagination {
            list-style-type: none;
            padding: 10px 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .pagination a {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            color: #000;
            border: 1px solid #ddd;
            margin: 0 4px;
            border-radius: 4px;
        }
        .pagination a.active {
            background-color: #4CAF50;
            color: white;
        }
        .pagination a:hover:not(.active) {background-color: #ddd;}
    </style>
</head>
<body>
    <br>
    <div id="navbar">
        <a href="../index.php" class="home"><img id="logo" src="../images/quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a></a>
        <a href="./PHP/profile.php">My Profile</a>
        <a></a>
        <a></a>
        <a href="./panel.php">Admin Panel<a>
        <a></a>
        <a></a>
        <?php
            // Start the session
            session_start();

            // Check if the user is logged in
            if (isset($_SESSION["username"])) {
                // If logged in, display logout option
                echo '<a href="./PHP/adminLogout.php" class="with_image home">Logout</a>';
                
                // Display the form when the user is signed in
                echo '<center><form action="./PHP/updateQuantity.php" method="post" style="font-style: normal; font-family:\'Lucida Sans\', \'Lucida Sans Regular\', \'Lucida Grande\', \'Lucida Sans Unicode\', Geneva, Verdana, sans-serif; font-size: 13px;" onsubmit="return validateForm()">
                    <pre>Book ID:                 <input type="text" name="id" id="id"><br><br></pre>
                    <pre>Quantity change to:      <input type="text" name="quantity" id="quantity"><br><br></pre>
                    <pre><br><input type="submit" name="changequantity" id="changequantity" value="Submit"> <input type="reset" name="reset" id="reset"></pre>
                </form></center>';
                
                // Display table only if admin is logged in
                echo '<div id="bookTable">';
                
                // Database connection
                $server = "localhost";
                $username = "root";
                $password = "";
                $database = "quickread";

                $connection = mysqli_connect($server, $username, $password, $database);

                if (!$connection) {
                    die("Connection failed: " . mysqli_connect_error());
                }

                // Pagination variables
                $results_per_page = 5; // Number of books per page

                // Determine current page number
                $page = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

                // Calculate the SQL LIMIT starting number for the results on the current page
                $offset = ($page - 1) * $results_per_page;

                // Query to retrieve books from the database, sorted by ID in ascending order
                $sql = "SELECT * FROM bookinfo ORDER BY id ASC LIMIT $offset, $results_per_page";
                $result = mysqli_query($connection, $sql);

                // Check if there are any books
                if (mysqli_num_rows($result) > 0) {
                    // Display books
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Title</th><th>Author</th><th>Quantity</th><th>Genre</th><th>Price</th></tr>";
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["title"] . "</td>";
                        echo "<td>" . (isset($row["authorName"]) ? $row["authorName"] : "N/A") . "</td>";
                        echo "<td>" . $row["quantity"] . "</td>";
                        echo "<td>" . $row["genre"] . "</td>";
                        echo "<td>$" . $row["price"] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "No books found.";
                }

                // Pagination links
                $total_pages = $connection->query('SELECT COUNT(*) FROM bookinfo')->fetch_row()[0];
                $num_pages = ceil($total_pages / $results_per_page);

                echo "<div class='pagination'>";
                if ($page > 1) {
                    echo "<a href='?page=" . ($page - 1) . "'>Prev</a>";
                }
                for ($i = 1; $i <= $num_pages; $i++) {
                    echo "<a href='?page=" . $i . "'>" . $i . "</a>";
                }
                if ($page < $num_pages) {
                    echo "<a href='?page=" . ($page + 1) . "'>Next</a>";
                }
                echo "</div>";

                // Close database connection
                mysqli_close($connection);
                
                echo '</div>'; // End of bookTable
            } else {
                // If not logged in, display sign in option
                echo '<a href="./adminLogin.html" class="with_image home">Sign in</a>';
            }
        ?>
    </div>
</body>
</html>

<?php
// Start the session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in
    if (isset($_SESSION["username"])) {
        // Database connection parameters
        $server = "localhost";
        $username = "root";
        $password = "";
        $database = "quickread";

        // Establish a connection to the database
        $connection = mysqli_connect($server, $username, $password, $database);

        // Check if the connection is successful
        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Get the form data
        $title = $_POST["newTitle"];
        $author = $_POST["author"];
        $genre = $_POST["genre"];
        $price = $_POST["price"];
        $quantity = $_POST["quantity"];

        // File upload handling for the image
        $targetDirectory = "uploads/"; // Specify the directory where images will be stored
        $targetFile = $targetDirectory . basename($_FILES["image"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        if (isset($_POST["addBook"])) {
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }

        // Check if file already exists
        if (file_exists($targetFile)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if (
            $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif"
        ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                echo "The file " . htmlspecialchars(basename($_FILES["image"]["name"])) . " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }

        // SQL query to insert the new book data into the database
        $sql = "INSERT INTO bookinfo (title, authorName, genre, price, quantity, image) VALUES ('$title', '$author', '$genre', $price, $quantity, '$targetFile')";

        // Execute the SQL query
        if (mysqli_query($connection, $sql)) {
            echo "New book added successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connection);
        }

        // Close the database connection
        mysqli_close($connection);
    } else {
        // If not logged in, redirect to the admin login page
        header("Location: ./adminLogin.html");
        exit();
    }
} else {
    // If form is not submitted, redirect to the admin panel page
    header("Location: ./panel.php");
    exit();
}
?>

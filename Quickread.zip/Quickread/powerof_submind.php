<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Document</title>
    <link href="home.css" rel="stylesheet">
</head>
<body>
    <br>
    <div id="navbar">
        
        <a href="index.php" class="home"><img id="logo" src="images\quickread_logo.png" alt="Logo"></a>
        <a href="./profile.php">My Profile</a>

        <?php
            session_start();

            // Check if the user is logged in
            if (isset($_SESSION["username"])) {
                // If logged in, display logout option or any other content for logged-in users
                echo '<a href="./PHP/logout.php">Logout</a>';
            } else {
                // If not logged in, display sign up form or any other content for non-logged-in users
                echo '<a href="./login.html">Sign In</a>';
            }
        ?>

        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="#" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="images\cart_image.png" width="19px">

        <a href="contantUs.html" class="category" class="home" >Contact Us</a>
        <br><br><br>
    </div>
    <div id="category">
        <a href="Categories\Fiction\fiction.html" >Fiction</a>
        <a href="Categories\Romantic\romantic.html"  >Romantic</a>
        <a href="Categories\Mystery\mystery.html" >Mystery</a>
        <a href="Categories\SciFiction\scifiction.html">Science Fiction</a>
        <a href="Categories\Children\children.html" >Children's literature</a>
        <a href="Categories\Comedy\comedy.html" >Comedy</a>
        <a href="Categories\Crime\crime.html" >Crime</a>

    </div>

    <div class="book_image">
    <img src="images\power of subco mind.png" alt="Power of Subconcious Mind" height="350px" width="235px" >
    <p>The Power of your subconscious mind</p>  
    <pre style="color:grey; ">Psychology</pre>
    <ins>₹ 200 <del>320</del></ins>
    <pre>    
</pre>
    <form action="./PHP/addToCartB.php" method="post"> <!-- Form for adding to cart -->
        <input type="hidden" name="bookName" value="Power Of Subconscious Mind">
        <input type="hidden" name="price" value="200">
        <input type="hidden" name="quantity" value="1">
        <button type="submit" class="add_to_cart" name="addToCart">Add to Cart</button>
    </form>
</body>
</html>
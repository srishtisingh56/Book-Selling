<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Quickread</title>
    <link href="HOME.css" rel="stylesheet">
</head>
<body>
    <br>
    <div id="navbar">
        
        <a href="./index.php" class="home"><img id="logo" src="images\quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a href="profile.php">My Profile</a>

        
        <?php
            session_start();

            // Check if the user is logged in
            if (isset($_SESSION["username"])) {
                // If logged in, display logout option or any other content for logged-in users
                echo '<a href="./PHP/logout.php">Logout</a>';
            } else {
                // If not logged in, display sign up form or any other content for non-logged-in users
                echo '<a href="./login.html">Sign In</a>';
            }
        ?>


        <!-- <a href="login.html" class="with_image home" >Sign in</a>
        <img id="sign_image" src="images\signin_image.png" width="19px"> -->
        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="cart.php" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="images\cart_image.png" width="19px">

        <a href="contantUs.html" class="category" class="home">Contact Us</a>
        <br><br><br>
    </div>

    <div id="category">
        <a href="Categories\Fiction\fiction.php" >Fiction</a>
        <a href="Categories\Romantic\romantic.html"  >Romantic</a>
        <a href="Categories\Mystery\mystery.html" >Mystery</a>
        <a href="Categories\SciFiction\scifiction.html">Science Fiction</a>
        <a href="Categories\Children\children.html" >Children's literature</a>
        <a href="Categories\Comedy\comedy.html" >Comedy</a>
        <a href="Categories\Crime\crime.html" >Crime</a>

    </div>
    <div class="hidden1 hidden fixed w-full h-screen bg-black/80"></div>
    <br><br><br><br><br><br>
    <div class="book-box" id="bookBox" >

        <div id="itends_withus" class="book">
            <a href="itends_withus.php">
                <img src="images\it end with us.png" alt="It ends with us" height="200px" width="135px" >
                
                <p class="small_para">It ends with us</p>
                <pre class="small_pre">Romance, Fictional</pre>
                <p class="small_para">₹ 200</p>
        </a>

    </div>

    <div id="richdad_poordad" class="book">

        <a href="richdad_poordad.php">
            <img src="images\rich dad poor dad.png" alt="Rich Dad Poor Dad" height="200px" width="135px" >
            <p class="small_para">Rich Dad Poor Dad</p>
            <pre class="small_pre">Psychology</pre>
            <p class="small_para">₹ 250</p>
        </a>
    </div>

    <div id="powerof_submind" class="book">
        <a href="powerof_submind.php">
            <img src="images\power of subco mind.png" alt="Power of Subconcious Mind" height="200px" width="135px" >
            <p class="small_para">The Power of your subconscious mind</p>
            <pre class="small_pre">Psychology</pre>
            <p class="small_para">₹ 200</p>
        </a>
    </div>

    <div id="thegirlwho_knewtoomuch" class="book">
        <a href="thegirlwho_knewtoomuch.php">
            <img src="images\the girl know too much.png" alt="The Girl who knew too much" height="200px" width="135px" >
            <p class="small_para">The Girl who knew too much</p>
            <pre class="small_pre">Fiction, Romance</pre>
            <p class="small_para">₹ 150</p>
        </a>
    </div>

    <div id="half_girlfriend" class="book">
        <a href="half_girlfriend.php">
            <img src="images\half girlfriend.png" alt="Half girlfriend" height="200px" width="135px" >
            <p class="small_para">Half Girlfriend</p>
            <pre class="small_pre">Novel, Romance</pre>
            <p class="small_para">₹ 150</p>
        </a>
    </div>

    <div id="mystery_ofhiddenlab" class="book">
        <a href="mystery_ofhiddenlab.php">
            <img src="images\the mystery of hidden lab.png" alt="The mystery of hidden lab" height="200px" width="135px" >
            <p class="small_para">The Mystery of the Hidden Lab</p>
            <pre class="small_pre">Mystery, Suspense</pre>
            <p class="small_para">₹ 200</p>
        </a>
    </div>
    <div id="TheIncarcerations" class="book">
        <a href="TheIncarcerations.php">
            <img src="images\TheIncarcerations.png" alt="The incarcerations" height="200px" width="135px" >
            <p class="small_para">The Incarcerations</p>
            <pre class="small_pre">Political Freedom, Security</pre>
            <p class="small_para">₹ 300</p>
        </a>
    </div>

</div>
<div class="book-box" id="bookBox">
        <div id="" class="book">
    
            <a href="whisperToMeYourLies.html">
                <img src="images\Mystery\whisperToMeYourLies - Copy.png" alt="Whisper To Me Your Lies" height="200px" width="135px" >
                <p class="small_para">Whisper To Me Your Lies</p>
                <pre class="small_pre">Suspense, Mystery</pre>
                <p class="small_para">₹ 300</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="wouldYouOpenTheBox.html">
                <img src="images\Mystery\wouldYouOpenTheBox.png" alt="Would You Open The Box" height="200px" width="135px" >
                <p class="small_para">Would You Open The Box</p>
                <pre class="small_pre">Suspense, Mystery</pre>

                <p class="small_para">₹ 250</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="nextDoor.html">
                <img src="images/Mystery/nextDoor.png" alt="Next Door" height="200px" width="135px" >
                <p class="small_para">Next Door</p>
                <pre class="small_pre">Suspense, Mystery</pre>

                <p class="small_para">₹ 510</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="theMahabharataQuest.html">
                <img src="images\Mystery\theMahabharataQuest.png" alt="the Mahabharata Quest" height="200px" width="135px" >
                <p class="small_para">The Mahabharata Quest</p>
                <pre class="small_pre">Suspense, Mystery</pre>

                <p class="small_para">₹ 800</p>
            </a>
        </div>
        <div id="Charlotte's_Web" class="book">
            <a href="Charlotte's_Web.html">
                <center><img src="images/Children's Literature/Charlotte's Web.jpg" alt="Charlotte's_Web" height="200px" width="135px" ></center>
                
                <p class="small_para">Charlotte's Web</p>
                <pre class="small_pre">Children's Literature</pre>
                <p class="small_para">₹ 456</p>
            </a>
        </div>

        <div id="Animals_Tales_From_Panchtantra" class="book">
            <a href="Animals_Tales_From_Panchtantra.html">
                <center><img src="images/Children's Literature/Animals Tales From Panchtantra.jpg" alt="Animals_Tales_From_Panchtantra" height="200px" width="135px" ></center>
                
                <p class="small_para">Animals Tales From Panchtantra</p>
                <pre class="small_pre">Children's Literature</pre>
                <p class="small_para">₹ 512</p>
            </a>
        </div>

        <div id="Bedtime_Stories" class="book">
            <a href="Bedtime_Stories.html">
                <center><img src="images/Children's Literature/Bedtime Stories.jpg" alt="Bedtime_Stories" height="200px" width="135px" ></center>
                
                <p class="small_para">Bedtime Stories</p>
                <pre class="small_pre">Children's Literature</pre>
                <p class="small_para">₹ 299</p>
            </a>
        </div>
        
    </div>
<div class="book-box" id="bookBox" >

<div id="" class="book">
    
            <a href="Always_theBridesmaid.html">
                <img src="images/RomanticBooks/Always the Bridesmaid.png" alt="Always the Bridesmaid" height="200px" width="135px" >
                <p class="small_para">Always the Bridesmaid</p>
                <pre class="small_pre">Romance, Fiction</pre>

                <p class="small_para">₹ 1500</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="The_SecretFiancee.html">
                <img src="images/RomanticBooks/The Secret Fiancee.png" alt="The Secret Fiancee" height="200px" width="135px" >
                <p class="small_para">The Secret Fiancee</p>
                <pre class="small_pre">Romance</pre>

                <p class="small_para">₹ 1999</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="TheLies_ofEternityLove.html">
                <img src="images/RomanticBooks/The Lies of EternityLove.png" alt="The Lies of EternityLove" height="200px" width="135px" >
                <p class="small_para">The Lies of Eternity Love</p>
                <pre class="small_pre">Romance, Mystery</pre>

                <p class="small_para">₹ 250</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="The_wrongWife.html">
                <img src="images/RomanticBooks/The Wrong Wife.png" alt="The Wrong Wife" height="200px" width="135px" >
                <p class="small_para">The Wrong Wife</p>
                <pre class="small_pre">Romance</pre>

                <p class="small_para">₹ 230</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="TheTouch_ofEternity.html">
                <img src="images/RomanticBooks/A Touch of Eternity.png" alt="A Touch of Eternity" height="200px" width="135px" >
                <p class="small_para">A Touch of Eternity</p>
                <pre class="small_pre">Romance</pre>

                <p class="small_para">₹ 799</p>
            </a>
        </div>
        <div id="The_Law_of_Revenge" class="book">
            <a href="The_Law_of_Revenge.html">
                <center><img src="images/Crime/The Law of Revenge.jpg" alt="The_Law_of_Revenge" height="200px" width="135px" ></center>
                
                <p class="small_para">The Law of Revenge</p>
                <pre class="small_pre">Crime, Mystery</pre>
                <p class="small_para">₹ 799</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="UntilForever.html">
                <img src="images/RomanticBooks/Until Forever.png" alt="Until Forever" height="200px" width="135px" >
                <p class="small_para">Until Forever</p>
                <pre class="small_pre">Romance, Suspense</pre>

                <p class="small_para">₹ 570</p>
            </a>
        </div>
    </div>
    <div class="book-box">
    <div id="" class="book">

        <a href="that_night.html">
            <img src="images/fictionBooks/That Night.png" alt="that night" height="200px" width="135px" >
            <p class="small_para">that night</p>
            <pre class="small_pre">Horror, Fiction</pre>

            <p class="small_para">₹ 200</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="ThePalace_ofIllusions.html">
            <img src="images/fictionBooks/The Palace Of Illusions.png" alt="The Palace of Illusions" height="200px" width="135px" >
            <p class="small_para">The Palace of Illusions</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 250</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="TheLaw_ofAttraction.html">
            <img src="images/fictionBooks/The Law Of Attraction.png" alt="The Law of Attraction" height="200px" width="135px" >
            <p class="small_para">The Law of Attraction</p>
            <pre class="small_pre">Love, Fiction</pre>

            <p class="small_para">₹ 310</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="Trust_NOone.html">
            <img src="images/fictionBooks/Trust No One.png" alt="Trust No One" height="200px" width="135px" >
            <p class="small_para">Trust No One</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 190</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="Girl_inSeat_2A.html">
            <img src="images/fictionBooks/Girl in Seat 2A.png" alt="The Girl in Seat 2A" height="200px" width="135px" >
            <p class="small_para">The Girl in Seat 2A</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 300</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="DaysAtThe_MorisakiBookshop.html">
            <img src="images/fictionBooks/Days at the Morisaki Bookshop.png" alt="Days at the Morisaki Bookshop" height="200px" width="135px" >
            <p class="small_para">Days at the Morisaki Bookshop</p>
            <pre class="small_pre">Fiction</pre>

            <p class="small_para">₹ 220</p>
        </a>
    </div>
    <div id="" class="book">

        <a href="YouOnly_LiveOnce.html">
            <img src="images/fictionBooks/You Only Live Once.png" alt="You Only Live Once"  height="200px" width="135px" >
            <p class="small_para">You Only Live Once</p>
            <pre class="small_pre">Suspense, Fiction</pre>

            <p class="small_para">₹ 170</p>
        </a>
    </div>
</div>
<div class="book-box">
        <div id="" class="book">
    
            <a href="EarthDivided.html">
                <img src="images\SciFiction\EarthDivided.png" alt="Earth Divided" height="200px" width="135px" >
                <p class="small_para">Earth Divided</p>
                <pre class="small_pre">Science Fiction</pre>
                <p class="small_para">₹ 400</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="scienceFiction.html">
                <img src="images\SciFiction\scienceFiction.png" alt="science Fiction" height="200px" width="135px" >
                <p class="small_para">Science Fiction</p>
                <pre class="small_pre">Science Fiction</pre>

                <p class="small_para">₹ 850</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="TheInvisibleMan.html">
                <img src="images\SciFiction\TheInvisibleMan.png" alt="The Invisible Man" height="200px" width="135px" >
                <p class="small_para">The Invisible Man</p>
                <pre class="small_pre">Science Fiction</pre>    

                <p class="small_para">₹ 900</p>
            </a>
        </div>
        <div id="" class="book">
    
            <a href="TwinOfTheAmazon.html">
                <img src="images\SciFiction\TwinOfTheAmazon.png" alt="Twin Of The Amazon" height="200px" width="135px" >
                <p class="small_para">Twin Of The Amazon</p>
                <pre class="small_pre">Science Fiction</pre>

                <p class="small_para">₹ 820</p>
            </a>
        </div>
        <div id="Never_Lie" class="book">
            <a href="Never_Lie.html">
                <center><img src="images/Crime/Never Lie.jpg" alt="Never_Lie" height="200px" width="135px" ></center>
                
                <p class="small_para">Never Lie</p>
                <pre class="small_pre">Crime, NonFiction</pre>
                <p class="small_para">₹ 309</p>
            </a>
        </div>

        <div id="Keep_Your_Friends_Close" class="book">
            <a href="Keep_Your_Friends_Close.html">
                <center><img src="images/Crime/Keep Your Friends Close.jpg" alt="Keep_Your_Friends_Close" height="200px" width="135px" ></center>
                
                <p class="small_para">Keep Your Friends Close</p>
                <pre class="small_pre">Crime, Mystery</pre>
                <p class="small_para">₹ 989</p>
            </a>
        </div>

        <div id="The_Complete_Novels_of_Sherlock_Holmes" class="book">
            <a href="The_Complete_Novels_of_Sherlock_Holmes.html">
                <center><img src="images/Crime/The Complete Novels of Sherlock Holmes.jpg" alt="The_Complete_Novels_of_Sherlock_Holmes" height="200px" width="135px" ></center>
                
                <p class="small_para">The Complete Novels of Sherlock Holmes</p>
                <pre class="small_pre">Crime, Mystery</pre>
                <p class="small_para">₹ 2999</p>
            </a>
        </div>
        
    </div>
    <div class="book-box">

        <div id="The_Hitchhiker's_Guide_to_the_Galaxy" class="book">
            <a href="./The_Hitchhiker's_Guide_to_the_Galaxy.html">
                <center><img src="images/comedy/The Hitchhiker's Guide to the Galaxy.jpg" alt="The_Hitchhiker's_Guide_to_the_Galaxy" height="200px" width="135px" ></center>
                
                <p class="small_para">The Hitchhiker's Guide to the Galaxy</p>
                <pre class="small_pre">Comedy, Science Fiction</pre>
                <p class="small_para">₹ 512</p>
            </a>
        </div>

        <div id="Where'd_You_Go,_Bernadette" class="book">
            <a href="Where'd_You_Go,_Bernadette.html">
                <center><img src="images/comedy/Where'd You Go, Bernadette.jpg" alt="Where'd_You_Go,_Bernadette" height="200px" width="135px" ></center>
                
                <p class="small_para">Where'd You Go, Bernadette</p>
                <pre class="small_pre">Comedy, Fiction, Crime</pre>
                <p class="small_para">₹ 470</p>
            </a>
        </div>

        <div id="Let's_Pretend_This_Never_Happened" class="book">
            <a href="Let's_Pretend_This_Never_Happened.html">
                <center><img src="images/comedy/Let's Pretend This Never Happened.jpg" alt="Let's_Pretend_This_Never_Happened" height="200px" width="135px" ></center>
                
                <p class="small_para">Let's Pretend This Never Happened</p>
                <pre class="small_pre">Comedy</pre>
                <p class="small_para">₹ 1299</p>
            </a>
        </div>

        <div id="I_Feel_Bad_About_My_Neck" class="book">
            <a href="I_Feel_Bad_About_My_Neck.html">
                <center><img src="images/comedy/I Feel Bad About My Neck.jpg" alt="I_Feel_Bad_About_My_Neck" height="200px" width="135px" ></center>
                
                <p class="small_para">I Feel Bad About My Neck</p>
                <pre class="small_pre">Comedy</pre>
                <p class="small_para">₹ 799</p>
            </a>
        </div>

        <div id="Red_White_&_Royal_Blue" class="book">
            <a href="Red_White_&_Royal_Blue.html">
                <center><img src="images/comedy/Red White & Royal Blue.jpg" alt="Red_White_&_Royal_Blue" height="200px" width="135px" ></center>
                
                <p class="small_para">Red White & Royal Blue</p>
                <pre class="small_pre">Comedy</pre>
                <p class="small_para">₹ 999</p>
            </a>
        </div>

        <div id="American_Cheese" class="book">
            <a href="American_Cheese.html">
                <center><img src="images/comedy/American Cheese.jpg" alt="American_Cheese" height="200px" width="135px" ></center>
                
                <p class="small_para">American Cheese</p>
                <pre class="small_pre">Comedy</pre>
                <p class="small_para">₹ 631</p>
            </a>
        </div>
        

    </div>



<!-- <script src="Javascript\HOME.js"></script> -->
<script src="Javascript\CommonForAll.js"></script>

</body>
</html>
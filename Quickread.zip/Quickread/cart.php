<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link href="HOME.css" rel="stylesheet">
    <style>
        /* CSS to center the book info */
        .Cart {
            text-align: center;
        }

        .book-info {
            display: inline-block;
            text-align: left;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: calc(100% - 20px);
            max-width: 600px;
        }

        /* CSS for the select dropdown */
        select {
            padding: 5px;
            border-radius: 5px;
            margin-bottom: 10px; /* Add margin bottom to create space */
        }

        /* CSS for the "Update Cart" button */
        .update-cart-btn {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 5px 10px; /* Adjust padding */
            text-align: center;
            text-decoration: none;
            font-size: 14px; /* Adjust font size */
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px; /* Add margin left */
        }

        /* CSS for the "Place Order" button */
        .place-order-btn {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <br>
    <div id="navbar">
    <a href="./index.php" class="home"><img id="logo" src="images\quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a href="profile.php">My Profile</a>

        
        <?php
            session_start();

            // Check if the user is logged in
            if (isset($_SESSION["username"])) {
                // If logged in, display logout option or any other content for logged-in users
                echo '<a href="./PHP/logout.php">Logout</a>';
            } else {
                // If not logged in, display sign up form or any other content for non-logged-in users
                echo '<a href="./login.html">Sign In</a>';
            }
        ?>


        <!-- <a href="login.html" class="with_image home" >Sign in</a>
        <img id="sign_image" src="images\signin_image.png" width="19px"> -->
        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="cart.php" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="images\cart_image.png" width="19px">

        <a href="contantUs.html" class="category" class="home">Contact Us</a>
        <br><br><br>
    </div>
    <div id="category">
    <a href="Categories\Fiction\fiction.html" >Fiction</a>
        <a href="Categories\Romantic\romantic.html"  >Romantic</a>
        <a href="Categories\Mystery\mystery.html" >Mystery</a>
        <a href="Categories\SciFiction\scifiction.html">Science Fiction</a>
        <a href="Categories\Children\children.html" >Children's literature</a>
        <a href="Categories\Comedy\comedy.html" >Comedy</a>
        <a href="Categories\Crime\crime.html" >Crime</a>
    </div>

    <div class="Cart">
        <h2>My Cart</h2>
        <?php
            session_start();
            // Check if the user is logged in
            if (!isset($_SESSION["username"])) {
                header("Location: ./login.html");
                exit();
            }

            // Database connection
            $server = "localhost";
            $username = "root";
            $password = "";
            $database = "quickread";
            $connection = mysqli_connect($server, $username, $password, $database);

            if (!$connection) {
                die("Connection failed: " . mysqli_connect_error());
            }

            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["updateCart"])) {
                foreach ($_POST["quantity"] as $id => $quantity) {
                    $id = mysqli_real_escape_string($connection, $id);
                    $quantity = mysqli_real_escape_string($connection, $quantity);
                    // Update the quantity in the cartitem table
                    $sql = "UPDATE cartitem SET quantity = $quantity WHERE id = $id";
                    mysqli_query($connection, $sql);
                }
            }

            // Retrieve data from cartitem table
            $sql = "SELECT * FROM cartitem";
            $result = mysqli_query($connection, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<form action='' method='post'>";
                // Display cart items
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='book-info'>";
                    echo "<p>Name: " . $row["name"] . "</p>";
                    echo "<p>Price: " . $row["price"] . "</p>";
                    // Add a select dropdown to change quantity
                    echo "<form action='' method='post'>";
                    echo "<label for='quantity'>Quantity:</label>";
                    echo "<select name='quantity[" . $row['id'] . "]'>";
                    // Loop to generate options from 1 to 10 (change as needed)
                    for ($i = 1; $i <= 10; $i++) {
                        // Set selected attribute for current quantity
                        if ($i == $row['quantity']) {
                            echo "<option value='$i' selected>$i</option>";
                        } else {
                            echo "<option value='$i'>$i</option>";
                        }
                    }
                    echo "</select>";
                    // Update Cart button for each item
                    echo "<button type='submit' name='updateCart' class='update-cart-btn'>Update Cart</button>";
                    echo "</form>";
                    echo "</div>";
                }
                // Update Cart button
                echo "</form>";
            } else {
                echo "Your cart is empty.";
            }

            mysqli_close($connection);
        ?>
        <!-- Place an order button -->
        <form action="./PHP/place_order.php" method="post">
            <button type="submit" name="placeOrder" class="place-order-btn">Place Order</button>
        </form>
    </div>
</body>
</html>

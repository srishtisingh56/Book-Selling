<?php
    session_start();

    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "quickread";
    
    $connect = mysqli_connect($server, $username, $password, $database);
    if (!$connect) {
        die("Connection failed: " . mysqli_connect_error());
        exit();
    }
    
    $cNumber = $_POST['cNumber'];
    $pass = $_POST['pass'];
    
    $sqlquery = "SELECT * FROM userinfo WHERE contact_number = '$cNumber' AND password = '$pass'";
    $result = mysqli_query($connect, $sqlquery);
    
    if (mysqli_num_rows($result) == 1) {
        // Username and password match, redirect to the account page
        $_SESSION['username'] = $cNumber;
        header("Location: ../index.php");
        exit();
    } else {
        // Username and password do not match, redirect back to the login page with an error message
        header("Location: ../login.html");
        exit();
    }
    mysqli_close($connect);
?>
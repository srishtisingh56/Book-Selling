<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["username"])) {
    // Redirect to login page if not logged in
    header("Location: ./login.html");
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["addToCart"])) {
    // Database connection
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "quickread";
    
    $connection = mysqli_connect($server, $username, $password, $database);
    
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get form data
    $name = $_POST["bookName"];
    $price = $_POST["price"];

    // Insert data into cartitem table
    $sql = "INSERT INTO cartitem (name, price) 
            VALUES ('$name', '$price')";

    if (mysqli_query($connection, $sql)) {
        // Redirect to cart.php
        header("Location: ../cart.php");
        exit();
    } else {
        echo "Error adding book to cart: " . mysqli_error($connection);
    }

    // Close database connection
    mysqli_close($connection);
}
?>

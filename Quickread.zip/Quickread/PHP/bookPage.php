<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Book Page</title>
    <link href="../../HOME.css" rel="stylesheet">
</head>
<body>
    <br>
    <div id="navbar">
        <!-- Navbar content -->
    </div>
    
    <div id="category">
        <!-- Category links -->
    </div>

    <div class="book-details">
        <!-- Assuming $bookId, $title, $authorName, $genre, $price, and $quantity are set -->
        <img src="../../images/<?php echo $genre; ?>/<?php echo $title; ?>.jpg" alt="<?php echo $title; ?>" height="350px" width="235px">
        <h2 id="bookName"><?php echo $title; ?></h2>
        <p id="author">Author: <?php echo $authorName; ?></p>
        <p id="genre">Genre: <?php echo $genre; ?></p>
        <p id="price">Price: ₹ <?php echo $price; ?> <del>₹ 999</del></p>
        <p id="quantity">Quantity: <?php echo $quantity; ?></p>
        <a href="book_detail.php?id=<?php echo $bookId; ?>">View Details</a>
    </div>
</body>
</html>

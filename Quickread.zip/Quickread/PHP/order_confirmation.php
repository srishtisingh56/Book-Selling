<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link href="../HOME.css" rel="stylesheet">
    <style>
        /* CSS for content */
        .container {
    max-width: 800px;
    margin: 80px auto 20px; /* Adjust the top margin to create space */
    padding: 20px;
    text-align: center;
}


        .confirmation {
            margin-top: 20px;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div id="navbar">
        <a href="../index.php" class="with_image home"><img id="logo" src="../images/quickread_logo.png" alt="Logo"></a>
        <a></a>
        <a href="../profile.php">My Profile</a>

        <?php
        session_start();

        // Check if the user is logged in
        if (isset($_SESSION["username"])) {
            // If logged in, display logout option
            echo '<a href="./PHP/logout.php">Logout</a>';
        } else {
            // If not logged in, display sign in option
            echo '<a href="./login.html">Sign In</a>';
        }
        ?>

        <input id="searchbar" placeholder="Search Title,Author...">
        <button id="searchbutton">Search</button>
        
        <a href="cart.php" class="with_image" class="home" >My Cart</a>
        <img id="cart_image" src="../images/cart_image.png" width="19px">

        <a href="contactUs.php" class="category" class="home">Contact Us</a>
        <br><br><br>
    </div>

    <div class="container">
        <div class="confirmation">
            <h2>Order Confirmed</h2>
            <?php
            // Check if total cost is passed as a parameter
            if (isset($_GET["total_cost"])) {
                $totalCost = $_GET["total_cost"];
                echo "<p>Your order has been placed successfully. Total Cost: $totalCost</p>";
            } else {
                echo "<p>Your order has been placed successfully.</p>";
            }
            ?>
            <p>Thank you for shopping with us!</p>
        </div>
    </div>
</body>
</html>

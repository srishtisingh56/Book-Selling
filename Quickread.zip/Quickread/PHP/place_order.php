<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["username"])) {
    // Redirect to login page if not logged in
    header("Location: ../login.html");
    exit();
}

// Database connection
$server = "localhost";
$username = "root";
$password = "";
$database = "quickread";

$connection = mysqli_connect($server, $username, $password, $database);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Retrieve user's contact number from session
$contactNumber = $_SESSION["username"];

// Retrieve data from cartitem table
$sql = "SELECT * FROM cartitem";
$result = mysqli_query($connection, $sql);

// Check if there are any items in the cart
if (mysqli_num_rows($result) > 0) {
    // Initialize total cost and flag for insufficient quantity
    $totalCost = 0;
    $insufficientQuantity = false;

    // Prepare statement for inserting order items
    $stmtOrderItem = $connection->prepare("INSERT INTO orderitem (contact_number, bookname, price, quantity, cost) VALUES (?, ?, ?, ?, ?)");

    // Bind parameters for order item insertion
    $stmtOrderItem->bind_param("ssdii", $contactNumber, $bookname, $price, $quantity, $cost);

    // Fetch cart items and insert into orderitem table
    while ($row = mysqli_fetch_assoc($result)) {
        $bookname = $row["name"];
        $price = $row["price"];
        $quantity = $row["quantity"];
        $cost = $price * $quantity; // Calculate cost based on quantity

        // Execute the order item insertion statement
        $stmtOrderItem->execute();

        // Increment total cost
        $totalCost += $cost;

        // Update book quantity in bookinfo table
        $stmtFetchBook = $connection->prepare("SELECT * FROM bookinfo WHERE title = ?");
        $stmtFetchBook->bind_param("s", $bookname);
        $stmtFetchBook->execute();
        $bookResult = $stmtFetchBook->get_result();

        if ($bookResult->num_rows > 0) {
            // Fetch book information
            $bookInfo = $bookResult->fetch_assoc();
            $bookId = $bookInfo['id'];
            $updatedQuantity = $bookInfo['quantity'] - $quantity;

            // Check if updated quantity is negative
            if ($updatedQuantity < 0) {
                // Set flag for insufficient quantity
                $insufficientQuantity = true;
            } else {
                // Update book quantity in bookinfo table
                $stmtUpdateQuantity = $connection->prepare("UPDATE bookinfo SET quantity = ? WHERE id = ?");
                $stmtUpdateQuantity->bind_param("ii", $updatedQuantity, $bookId);
                $stmtUpdateQuantity->execute();
                $stmtUpdateQuantity->close();
            }
        } else {
            // Book not found in bookinfo table
            // Set flag for insufficient quantity
            $insufficientQuantity = true;
        }

        // Close statement
        $stmtFetchBook->close();
    }

    // Close statement
    $stmtOrderItem->close();

    // Clear cart after placing order
    $sql = "DELETE FROM cartitem";
    mysqli_query($connection, $sql);

    // Redirect to a confirmation page or any other page
    if ($insufficientQuantity) {
        // Redirect to cart page with error message
        header("Location: ./cart.php?error=insufficient_quantity");
    } else {
        // Redirect to order confirmation page
        header("Location: ./order_confirmation.php?total_cost=" . $totalCost);
    }
} else {
    // If cart is empty, redirect to cart page or any other page
    header("Location: ../cart.php");
}

// Close database connection
mysqli_close($connection);
?>
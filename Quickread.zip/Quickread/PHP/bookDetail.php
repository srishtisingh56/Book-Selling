<?php
    // Establish a database connection
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "quickread";
    
    $connection = mysqli_connect($server, $username, $password, $database);
    
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Retrieve book details from the database
    $bookId = $_GET['id']; // Assuming you pass the book ID through a GET parameter
    $sql = "SELECT * FROM bookinfo WHERE id = $bookId";
    $result = mysqli_query($connection, $sql);

    if (!$result) {
        die("Query failed: " . mysqli_error($connection));
    }

    if (mysqli_num_rows($result) > 0) {
        // Fetch book data
        $bookData = mysqli_fetch_assoc($result);

        // Store book details in variables
        $title = $bookData["title"];
        $authorName = $bookData["authorName"];
        $genre = $bookData["genre"];
        $price = $bookData["price"];
        $quantity = $bookData["quantity"];
    }
?>

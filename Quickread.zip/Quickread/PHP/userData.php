<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $cNumber = stripslashes($_POST['cNumber']);
        $address = isset($_POST['address']) ? $_POST['address'] : "";
        $pass = $_POST['pass'];
        $confirmPass = $_POST['confirmPass'];
    
        // Check if password and confirm password match
        if ($pass !== $confirmPass) 
        {
            echo "Error: Passwords do not match.";
            exit();
        }
        else
        {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "quickread";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
	            die("Connection failed: ". $conn->connect_error);
                exit();
            }
            // Taking all 5 values from the form data(input)
            $name =  $_REQUEST['name'];
            $address = $_REQUEST['address'];
            $cNumber = $_REQUEST['cNumber'];
            $email = $_REQUEST['email'];
            $pass =  $_REQUEST['pass'];
            //echo $pass;

            $sqlquery = "INSERT INTO userinfo (contact_number, name, address, password, email) VALUES ('$cNumber', '$name', '$address', '$pass', '$email')";
            // $sqlquery = "INSERT INTO userinfo (contact_number, name, address, password, email) VALUES ('9876546215', 'mahek', 'abc', 'Mahek@05', 'abc@bvm.com')";
            if ($conn->query($sqlquery) === TRUE) 
            {
	            echo "record inserted successfully";
                header("Location: ../login.html");
            } 
            else 
            {
	            echo "Error: " . $sqlquery . "<br>" . $conn->error;
                exit();
            }
        }
    }
    
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $cNumber = stripslashes($_POST['cNumber']);
    $message = $_POST['message']; // Add a semicolon here
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "quickread";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO complaint (contact_number, name, message, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $cNumber, $name, $message, $email);

    if ($stmt->execute()) {
        echo "Record inserted successfully";
        header("Location: ./contactUs.html");
        exit();
    } else {
        echo "Error: " . $stmt->error;
        exit();
    }
}
?>
